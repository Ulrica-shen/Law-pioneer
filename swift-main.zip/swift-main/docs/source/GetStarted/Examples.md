# LLM训练方案

Swift提供了完整的LLM训练方案，可以查看[Examples的README](https://github.com/modelscope/swift/blob/main/examples/pytorch/llm/README_CN.md).

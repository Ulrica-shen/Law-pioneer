swift.tuners
==============

.. automodule:: swift.tuners

.. currentmodule:: swift.tuners

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    adapter.AdapterConfig
    base.SwiftModel
    base.Swift
    lora.LoRAConfig
    prompt.PromptConfig
    restuning.ResTuningConfig
    side.SideConfig
    utils.SwiftConfig
    utils.SwiftOutput

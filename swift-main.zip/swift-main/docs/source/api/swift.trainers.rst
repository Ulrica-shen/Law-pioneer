swift.trainers
==============

.. automodule:: swift.trainers

.. currentmodule:: swift.trainers

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    trainers.Seq2SeqTrainer
    trainers.Trainer

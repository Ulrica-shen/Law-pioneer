swift.hub
==============

.. automodule:: swift.hub

.. currentmodule:: swift.hub

.. autosummary::
    :toctree: generated
    :nosignatures:
    :template: classtemplate.rst

    api.HubApi
    check_model.check_local_model_is_latest
    push_to_hub.push_to_hub
    push_to_hub.push_to_hub_async
    snapshot_download.snapshot_download
    file_download.model_file_download
